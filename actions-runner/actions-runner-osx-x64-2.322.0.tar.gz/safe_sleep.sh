#!/bin/bash

SECONDS=0
while [[ $SECONDS != $1 ]]; do
    :
done
